import azure.functions as func
import json
import logging
import requests
import os
import base64
import time
import random
from datetime import datetime
from typing import List

app = func.FunctionApp()

def send_with_retry(http_endpoint, headers, payload, max_retries=3):
    """
    Send HTTP request with retry logic and exponential backoff.
    """
    for attempt in range(max_retries):
        try:
            response = requests.post(
                http_endpoint,
                json=payload,
                headers=headers,
                timeout=60
            )
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            if attempt < max_retries - 1:
                # Exponential backoff with jitter
                delay = (2 ** attempt) + random.uniform(0, 1)
                logging.warning(f"Attempt {attempt + 1} failed: {e}. Retrying in {delay:.2f}s")
                time.sleep(delay)
            else:
                logging.error(f"Failed after {max_retries} attempts: {e}")
                raise

@app.event_hub_message_trigger(
    arg_name="events", 
    event_hub_name="%EventHubName%",
    connection="EventHubConnectionString",
    consumer_group="$Default",
    cardinality=func.Cardinality.MANY
)
def EventHubFunction(events: List[func.EventHubEvent]) -> None:
    """
    Azure Function triggered by Event Hub messages.
    Processes events and forwards them to an HTTP endpoint.
    """
    
    # Get configuration from environment variables
    http_endpoint = os.environ.get("HTTP_ENDPOINT_URL")
    username = os.environ.get("HTTP_USERNAME")
    password = os.environ.get("HTTP_PASSWORD")
    
    if not http_endpoint:
        logging.error("HTTP_ENDPOINT_URL environment variable is not set")
        return
    
    if not username or not password:
        logging.error("HTTP_USERNAME or HTTP_PASSWORD environment variable is not set")
        return
    
    # Process each event - extract only raw bodies as strings
    raw_events = []
    
    for event in events:
        try:
            # Get only the raw event body as string
            event_body = event.get_body().decode('utf-8')
            raw_events.append(event_body)
            
            logging.info(f"Processed Event Hub event - Partition: {event.partition_key}, Sequence: {event.sequence_number}")
            
        except Exception as e:
            logging.error(f"Error processing event: {str(e)}")
    
    # Send raw events to HTTP endpoint
    if raw_events:
        try:
            # Setup headers
            headers = {
                "Content-Type": "application/json",
                "User-Agent": "Azure-Function-EventHub-Forwarder"
            }
            
            # Add Basic Authentication
            credentials = f"{username}:{password}"
            encoded_credentials = base64.b64encode(credentials.encode('utf-8')).decode('ascii')
            headers["Authorization"] = f"Basic {encoded_credentials}"
            
            # Parse and flatten all Event Grid events for clean batching
            all_events = []
            for raw_event in raw_events:
                try:
                    # Parse the Event Grid events array from Event Hub
                    parsed_events = json.loads(raw_event)
                    if isinstance(parsed_events, list):
                        all_events.extend(parsed_events)
                    else:
                        all_events.append(parsed_events)
                except json.JSONDecodeError:
                    # If not JSON, wrap in an object
                    all_events.append({"raw_message": raw_event})
            
            # Get max retries from environment or use default
            max_retries = int(os.environ.get("MAX_RETRIES", "3"))
            
            # Send all events in a single batch with retry logic
            response = send_with_retry(http_endpoint, headers, all_events, max_retries)
            
            logging.info(f"Successfully sent batch of {len(all_events)} events. Status: {response.status_code}")
            
        except Exception as e:
            logging.error(f"Failed to send events after all retries: {str(e)}")
    
    else:
        logging.warning("No events to process")